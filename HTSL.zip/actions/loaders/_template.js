export default (actionData) => {
	let sequence = [];

	return ['', sequence];
}