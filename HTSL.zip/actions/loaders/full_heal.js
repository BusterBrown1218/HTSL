export default (actionData) => {
	let sequence = [];
	
	return ['Full Heal', sequence];
}