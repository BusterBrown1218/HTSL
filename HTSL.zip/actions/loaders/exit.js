export default (actionData) => {
	let sequence = [];

	return ['Exit', sequence];
}