export default (actionData) => {
	let sequence = [];

	return ['Cancel Event', sequence];
}