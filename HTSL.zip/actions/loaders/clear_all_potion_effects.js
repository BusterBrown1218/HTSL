export default (actionData) => {
	let sequence = [];
	
	return ['Clear All Potion Effects', sequence];
}