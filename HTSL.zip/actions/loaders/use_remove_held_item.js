export default (actionData) => {
	let sequence = [];

	return ['Use/Remove Held Item', sequence];
}