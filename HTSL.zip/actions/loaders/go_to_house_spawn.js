export default (actionData) => {
	let sequence = [];

	return ['Go To House Spawn', sequence];
}