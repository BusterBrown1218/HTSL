export default (actionData) => {
	let sequence = [];

	return ['Parkour Checkpoint', sequence];
}