export default (actionData) => {
	let sequence = [];
	
	return ['Kill Player', sequence];
}