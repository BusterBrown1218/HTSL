export default (actionData) => {
	let sequence = [];
	
	return ['Reset Inventory', sequence];
}